Polski
; Zgodne z ffdshow tryouts revision 2768  Mar  10 2009 15:01:54 (msvc 2008, x86, unicode, r)
; Lokalizacja:
; Piotr Sok�, Radzio, Virtual_ManPL

[Font]
horizontalScale9x=125
horizontalScaleNT=125

[-1]
ffdshow video decoder configuration=Konfiguracja dekodera video ffdshow
ffdshow audio decoder configuration=Konfiguracja dekodera audio ffdshow
ffdshow video encoder configuration=Konfiguracja kodera video ffdshow
ffdshow video processor configuration=Konfiguracja przetwarzania video ffdshow
;
ffdshow audio decoder=Dekoder audio ffdshow
ffdshow video decoder=Dekoder video ffdshow
ffdshow video encoder=Koder video ffdshow
;
off=wy��czone
No=Nie
Reset=Resetuj
Edit=Edytuj
Edit trackbar value=Edytuj warto�� suwaka
Enter value in range from %i to %i=Wpisz warto�� z zakresu od %i do %i 
;
Thank you!=Dzi�kuj�!
Export ffdshow settings=Eksportuj ustawienia
Settings have been succefully exported=Ustawienia zosta�y pomy�lnie wyeksportowane
left=W lewo
center=Na �rodek
right=W Prawo
top=G�ra
bottom=d�
;
; Ustawienia DirectShow
do not use=Nie u�ywaj
unlikely=Niski
normal=Normalny
preferred=Preferowany
ffdshow default=Domy�lne ffdshow
very high=Bardzo wysoki
;
no limitations=Nie limituj
only one - check previous filter only=Tylko jedno - sprawd� tylko poprzedni filtr
only one - check all previous filters=Tylko jedno - sprawd� wszystkie poprzednie filtry
only one - check all filters in graph=Tylko jedno - sprawd� wszystkie filtry grafu
none - disabled=Brak - wy��czone
;
List of applications for which ffdshow should not load, separated by semicolons=Lista aplikacji, kt�re nie powinny u�ywa� ffdshow - rozdzielona �rednikami.
List of applications which are compatible with ffdshow, separated by semicolons.=Lista aplikacji kompatybilnych z ffdshow - rozdzielona �rednikami.
List the names of executable files which are incompatible with ffdshow or which you don't want to use ffdshow, one for each line.=Lista nazw plik�w wykonywalnych aplikacji niekompatybilnych z ffdshow, b�d� kt�rych nie chcesz by u�ywa�y ffdshow - jedna w ka�dym wierszu.
Add incompatible executable file=Wska� niekompatybilny plik wykonywalny
Add compatible executable file=Wska� kompatybilny plik wykonywalny
Load default settings=Przywr�� ustawienia domy�lne
Are you sure?=Czy jeste� pewny?
;
ffdshow will behave as if it were not installed.=ffdshow zachowa si� tak, jakby nie by� zainstalowany.
ffdshow will behave as if it were not installed.\r\nThe application will be added to "DirectShow control"->"Don't use ffdshow in".=ffdshow zachowa si� tak jakby nie by� zainstalowany.\r\nAplikacja zostanie dodana do listy "Ustawienia DirectShow"->"Nie u�ywaj ffdshow w:".
ffdshow will be used if it is set to decode a format.=ffdshow zostanie u�yty, o ile wcze�niej zosta� skonfigurowany tak by dekodowa� dany format.
ffdshow will be used if it is set to decode a format.\r\nThe application will be added to "DirectShow control"->"Use ffdshow only in".=ffdshow zostanie u�yty, o ile wcze�niej zosta� skonfigurowany tak by dekodowa� dany format. Aplikacja zostanie dodana do listy "Ustawienia DirectShow"->"U�ywaj ffdshow w:".
Thank you. We are gathering the list of compatible applications. Please send us the exe file name of this application and help us improving ffdshow.=Dzi�kujemy. Gromadzimy list� kompatybilnych aplikacji. Prosimy - wy�lij nam nazw� pliku exe tej aplikacji i pom� nam ulepsza� ffdshow.
ffdshow won't be used in unknown applications.\r\nTo enable this dialog again, check "DirectShow control"->"Show dialog when an unknown application tries to load ffdshow".=ffdshow nie b�dzie u�ywany w nieznanych aplikacjach.\r\nBy wy�wietla� to okno ponownie, zaznacz "Ustawienia DirectShow"->"Wy�wietlaj dialog kiedy nieznana aplikacja pr�buje za�adowa� ffdshow".
;
; OSD
New=Nowy
Save as...=Zapisz jako...
Save preset to...=Zapisz profil do...
New preset...=Nowy profil
Rename preset...=Zmie� nazw�...
Delete preset=Usu�
Show on startup=Poka� przy starcie
Don't display, only save data to file=Nie pokazuj, jedynie zapisz dane do pliku
File where to write statistics=Zapisz plik statystyk
New preset name=Nazwa profilu
Enter new preset name=Podaj nazw� profilu
Do you really want to delete current OSD preset?=Czy na pewno chcesz usun�� bie��cy profil OSD?
Startup OSD preset=Profil OSD przy starcie
Number of frames to show preset=Liczba klatek podczas trwania kt�rych profil OSD b�dzie aktywny
;
; Czcionka
Default=Domy�lne
Spacing - distance between characters.=Odst�py - odleg�o�� pomi�dzy znakami.
Weight - most fonts supports only small subset of listed weights.=Styl czcionki - wi�kszo�� czcionek wspiera tylko niewielk� grup� z podanego zestawu styl�w.
It is fast, but spaces between characters are not precise.=Dzia�a szybko, ale odst�py mi�dzy znakami nie s� precyzyjne.
Works when the video has non-square pixel aspect ratio.=Dzia�a, gdy obraz ma nie-kwadratowe proporcje bok�w punktu.
;
thin=W�ski
extralight=Przew�ony
light=�agodny
normal=Normalny
medium=�redni
semibold=P�wyt�uszczony
bold=Wyt�uszczony
extrabold=Ekstra wyt�uszczony
heavy=Intensywny
;
Glowing shadow=Cie� promienisty
Gradient shadow=Cie� gradientowy
Classic shadow=Cie� klasyczny
Disabled=Wy��czony
;
; Ikony, �cie�ki i konfiguracja
Select ffdshow instalation directory=Wska� folder instalacji ffdshow
Select directory with installed DScaler=Wska� folder instalacji DScaler
;
; Profile ustawie�
From default=Z domy�lnego
From selected=Z zaznaczonego
From file...=Z pliku...
;
Load ffdshow preset=Otw�rz profil ffdshow
Save ffdshow preset=Zapisz profil ffdshow
Rename=Zmie� nazw�
Insert file name=Wstaw nazw� pliku
Insert exe file name=Wstaw nazw� aplikacji
Removing preset=Usuwanie profilu
Do you really want to remove selected preset?=Czy na pewno chcesz usun�� zaznaczony profil?
Preset name=Nazwa profilu
;
; O programie
Library=Biblioteka
Version=Wersja
;
; Konfiguracja dekodera video
;   Kodeki
Format=Format
Decoder=Dekoder
Details=Szczeg�y
Supported FOURCCs/remarks=Obs�ugiwane kody FOURCC / uwagi
;
Set all stable formats to libavcodec=Ustaw wszystkie stabilne formaty na libavcodec
Set all supported formats to Xvid=Ustaw wszystkie zgodne formaty na Xvid
;
enabled=W��czony
disabled=Wy��czony
all supported=Wszystkie
all YUV=Wszystkie YUV
all RGB=Wszystkie RGB
8-bit palletized=8-bitowe
;
H264, X264, VSSH (incomplete), DAVC, PAVC, AVC1=H264, X264, VSSH (niekompletne), DAVC, PAVC, AVC1
Other MPEG4=Inne MPEG4
ffdshow and ffvfw internal FOURCCs=natywne FOURCC ffdshow i ffvfw
H263, L263, M263, U263, X263, S263 (in 3gp files)=H263, L263, M263, U263, X263, S263 (w plikach 3gp)
MPEG1 codec=kodek MPEG1
MPEG2 codec=kodek MPEG2
MPEG in AVI=MPEG w AVI
Other MPEG2=Inne MPEG2
Huffyuv codec for libavcodec (HFYU, FFVH)=Huffyuv dla libavcodec (HFYU, FFVH)
Other MJPEG=Inne MJPEG
Other DV=Inne DV
FFV1 codec for libavcodec (FFV1)=FFV1 dla libavcodec (FFV1)
Real Video (RV10, RV20, incomplete)=Real Video (RV10, RV20, niekompletne)
Doesn't support 24-bit compression.=Nie obs�uguje 24-bitowej kompresji.
AVIS (AviSynth AVI files)=AVIS (pliki AVI AviSynth)
Raw video=Nieskompresowany
;
skip deblocking when safe=Pomi� deblocking, gdy bezpiecznie
skip deblocking always=Zawsze pomijaj deblocking
Internal postprocessing=Natywne przetwarzanie
use speedup tricks=Przyspiesz
DVD decoding=Dekodowanie DVD
discard telecine=Ignoruj Telekino
Enable in WMP11=W��cz w WMP11
;
all integer=Wszystkie sta�oprzecinkowe
all float=Wszystkie zmiennoprzecinkowe
8-bit integer=8 bit sta�oprzecinkowy
16-bit integer=16 bit sta�oprzecinkowy
24-bit integer=24 bit sta�oprzecinkowy
32-bit integer=32 bit sta�oprzecinkowy
32-bit float=32 bit zmiennoprzecinkowy
64-bit float=64 bit zmiennoprzecinkowy
;
;   Informacje i CPU & OSD
Input description=Szczeg�y strumienia wej�cia
Output description=Szczeg�y strumienia wyj�cia
MD5 sum=Suma kontrolna MD5
Input aspect ratio=Proporcje strumienia wej�cia
Output aspect ratio=Proporcje strumienia wyj�cia
Input size and aspect ratio=Rozmiar i proporcje strumienia wej�cia
Frame timestamps=Znaczniki czasu klatki
Active preset name=Nazwa bie��cego profilu
Frame duration=Czas trwania klatki
Host application=Aplikacja
Source file name=Nazwa pliku
Current frame=Bie��ca klatka
Decoder FPS=Klatek/s dekodera
Queued samples=Kolejkowanie pr�bek
Video delay=Op�nienie strumienia video
Time on ffdshow=Czas ffdshow
AviSynth info=Informacja AviSynth
Accurate deblocking=Precyzyjny deblocking
Frame type=Typ klatki
Subtitles delay=Op�nienie napis�w
Coded frame size=Rozmiar kodowanej klatki
Input colorspace=Przestrze� kolor�w wej�cia
Input size=Rozmiar klatki wej�cia
Output size=Rozmiar klatki wyj�cia
CPU load=U�ycie procesora
System time=Czas systemowy
Frame mean quantizer=Kwantyzator aktualnej klatki
Current playing time=Czas odtwarzania
Remaining time=Pozosta�y czas odtwarzania
Movie length=Czas trwania filmu
Input bitrate=Bitrate strumienia wej�cia
Encoder info=Informacja kodera
Short configuration description=Kr�tki opis konfiguracji
GMC warp points=Ilo�� wektor�w przesuni�cia w GMC
Output colorspace=Przestrze� kolor�w wyj�cia
Movie FPS=Klatek/s filmu
Source file=Nazwa pliku
Input FOURCC=Kod FOURCC wej�cia
;
;   Klawisze i sterowanie
Action=Akcja
Key=Klawisz
;
Activation key 1=Klawisz aktywacji 1
Activation key 2=Klawisz aktywacji 2
Second function=Drugie polecenie
Seek forward=Skocz w prz�d
Seek backward=Skocz w ty�
Toggle OSD=W��cz / Wy��cz OSD
Toggle visualizations=W��cz / Wy��cz Wizualizacje
Toggle crop/zoom=W��cz / Wy��cz Przycinanie
Toggle deinterlace=W��cz / Wy��cz Usu� przeplot
Toggle levels=W��cz / Wy��cz Poziomy
Toggle noise=W��cz / Wy��cz Szum
Toggle picture properties=W��cz / Wy��cz W�a�ciwo�ci obrazu
Toggle postprocessing=W��cz / Wy��cz Przetwarzanie
Toggle blur=W��cz / Wy��cz Rozmywanie
Toggle resize=W��cz / Wy��cz Zmiana rozmiaru
Toggle subtitles=W��cz / Wy��cz Napisy
Toggle sharpen=W��cz / Wy��cz Wyostrzanie
Toggle flip=Przerzu� w pionie
Toggle avisynth=W��cz / Wy��cz AviSynth
Toggle warpsharp=W��cz / Wy��cz Warpsharp
Grab frame=Zrzu� klatk�
Subtitles delay/size decrease=Zmniejsz op�nienie / rozmiar napis�w
Subtitles delay/size increase=Zwi�ksz op�nienie / rozmiar napis�w
Subtitles position decrease=Przesu� napisy w d�
Subtitles position increase=Przesu� napisy w g�r�
Decrease video delay=Zmniejsz op�nienie video
Increase video delay=Zwi�ksz op�nienie video
Previous preset=Poprzedni profil
Next preset=Nast�pny profil
;
press key=naci�nij klawisz
left arrow=strza�ka w lewo
up arrow=strza�ka w g�r�
right arrow=strza�ka w prawo
down arrow=strza�ka w d�
left win=lewy Windows
right win=prawy Windows
menu key=klawisz menu
;
Select name of exported Girder file=Wybierz nazw� eksportowanego pliku Grider'a
;
;   Profile ustawie� \ ustawienia auto�adowania
Preset '%s' will be autoloaded ...=Profil '%s' zostanie wczytany automatycznie...
and=i
or=lub
;
on movie file name match with preset name=dla nazwy pliku takiej samej jak nazwa profilu
on movie file name match (with wildcards)=dla danej nazwy pliku (symbole wieloznaczne)
on application exe file name match=dla danej nazwy aplikacji
on volume name match=dla danej nazwy woluminu
on volume serial match=dla danego numeru woluminu
on decoder match=dla danego dekodera
on a DirectShow filter presence=dla danego filtra DirectShow
on FOURCC match=dla danego kodu FOURCC
on FOURCC from previous filter match=dla kodu FOURCC poprzedniego filtra
on pixel aspect ratio match=dla danych proporcji bok�w punktu
on picture aspect ratio match=dla danych proporcji bok�w obrazu
on frame rate match=dla danej liczby klatek/s
;
Preset autoload condition help=Pomoc ustawie� auto�adowania
Names of DirectShow filters, wildcard allowed=Nazwy filtr�w DirectShow, symbole wieloznaczne dozwolone
Useful when FFDShow is in raw mode, the compressed format (if any) is given by the previous filter in the chain.=U�yteczne kiedy ffdshow jest w trybie raw, format kompresji (je�li jest) zwracany jest przez poprzedni filtr w �a�cuchu grafu.
;
;   Usuwanie logo
Blur:=Rozmycie:
Exponent:=Wyk�adnik:
;
Over video=Na obrazie
Over top letterbox=Na g�rnej ramce
Over top & left letterbox=Na g�rnej i lewej ramce
Over top & right letterbox=Na g�rnej i prawej ramce
Over bottom letterbox=Na dolnej ramce
Over bottom & left letterbox=Na dolnej i lewej ramce
Over bottom & right letterbox=Na dolnej i prawej ramce
Over left letterbox=Na lewej ramce
Over right letterbox=Na prawej ramce
;
Direct=Bezpo�rednio
Opposite=Przeciwnie
Interpolation=Interpolacja
;
;   Rozmywanie
radius:=promie�:
luma blur:=luminancja:
chroma blur:=chrominancja:
time:=czas:
luma:=luminancja:
chroma:=chrominancja:
;
;   Wyostrzanie
Unsharp masking threshold:=Zasi�g maski wyostrzaj�cej:
Adaptive sharpenning strength:=Si�a wyostrzania:
Luminance sharpening:=Wyostrzanie luminancji:
Chroma sharpening:=Wyostrzanie chrominancji:
;
;   Warpsharp
downsampled=Wyr�wnanie w d�
independent=Niezale�nie
high quality 3-pass=Wysoka jako�� 3-przebiegi
fast 3-pass=Szybki 3-przebiegi
fast 1-pass=Szybki 1-przebieg
;
;   Filtr DScaler
Select DScaler filter=Wska� filtr DScaler
;
;   Szum
amplitude=amplituda
frequency=cz�stotliwo��
duration=czas
size=rozmiar
opacity=przezroczysto��
color=kolor
black=czarny
gray=szary
white=bia�y
;
;   Zmiana rozmiaru
greater than=wi�ksza ni�
less than=mniejsza ni�
;
default=Domy�lnie
Parameter=Parametr:
Number of taps:=Liczba wsp�czynnik�w:
;
2.40 (cinemascope, HD discs)=2.40 (cinemascope, p�yty HD)
;
;   Zmiana rozmiaru / Ramki
Brightness x is interpreted as RGB(x,x,x) and converted to luma using the settings in RGB conversion page, if necessary.=Jasno�� x jest interpretowana jako RGB(x,x,x) a nast�pnie je�li potrzeba, zamieniana na luminancje wed�ug ustawie� na karcie "Konwersja RGB".
;
;   Korekcja perspektywy
None=Brak
;
;   AviSynth
Load Avisynth script=Otw�rz skrypt AviSynth
Save Avisynth script=Zapisz skrypt AviSynth
;
Ignore pulldown=Ignoruj pulldown
Apply pulldown=Zastosuj pulldown
Smooth timestamps=P�ynne znaczniki czasu
;
;   DTC
Load quantization matrices=Otw�rz matryc� kwantyzacji
Save quantization matrices=Zapisz matryc� kwantyzacji
;
;   Nak�adaie bitmapy
Load image file=Otw�rz plik obrazu
;
blend=Mieszanie
darken=Przyciemnienie
lighten=Rozja�nienie
add=Dodanie
softlight=Softlight
exclusion=Wykluczenie
;
;   Napisy
Select directory where subtitles are stored=Wska� folder, w kt�rym przechowywane s� napisy
Load subtitles file=Otw�rz plik napis�w
Very incomplete and experimental.\nSend me samples which don't work.=Opcja niekompletna i eksperymentalna.
;
;   Napisy \ Text
subtitle=Dialog
line=Wiersz
character=Znak
;
Smart wrapping, lines are evenly broken=Sprytne dzielenie - wiersze �amane s� r�wnomiernie
End-of-line word wrapping=Dzielenie s��w na ko�cu wiersza
Smart wrapping, lower line gets wider=Sprytne dzielenie - dolny wiersz jest szerszy
;
;   Napisy \ VobSub
English (may work with other languages)=Angielski (mo�e dzia�a� z innymi j�zykami)
(Afan) Oromo=(Afan) Oromo
Abkhazian=Abchaski
Albanian=Alba�ski
Amharic=Amharski
Aragonese=Arago�ski
Armenian=Ormia�ski
Assamese=Assamski
Avaric=Awarski
Avestan=Awestyjski
Aymara=Ajmara
Azerbaijani=Azerski
Bashkir=Baszkirski
Basque=Baskijski
Belarusian=Bia�oruski
Bengali; Bangla=Bengalski
Bosnian=Bo�niacki
Breton=Breto�ski
Bulgarian=Bu�garski
Burmese=Birma�ski
Cambodian=Khmerski
Catalan=Katalo�ski
Corsican=Korsyka�ski
Czech=Czeski
Dansk=Du�ski
Deutsch=Niemiecki
English=Angielski
Espanol=Hiszpa�ski
Estonian=Esto�ski
Faroese=Farerski
Fijian=Fid�yjski
Finnish=Fi�ski
French=Francuski
Frisian=Fryzyjski
Galician=Galicyjski
Georgian=Gruzi�ski
Greenlandic=Grenlandzki
Gujarati=Gud�arati
Hrvatski=Chorwacki
Hungarian=W�gierski
Icelandic=Islandzki
Indonesian=Indonezyjski
Irish=Irlandzki
Italian=W�oski
Japanese=Japo�ski
Javanese=Jawajski
Kashmiri=Kaszmirski
Kazakh=Kazachski
Kinyarwanda=Ruanda-rundi
Kirghiz=Kirgiski
Korean=Korea�ski
Kurdish=Kurdyjski
Laothian=Laota�ski
Latin=�aci�ski
Latvian, Lettish=�otewski
Lithuanian=Litewski
Macedonian=Macedo�ski
Malagasy=Malgaski
Malay=Malajski
Malayalam=Malajalam
Maltese=Malta�ski
Maori=Maoryski
Moldavian=Mo�dawski
Mongolian=Mongolski
Nauru=Naurua�ski
Nederlands=Niderlandzki
Nepali=Nepalski
Norsk=Nowonorweski
Norwegian=Norweski
Occitan=Oksyta�ski
Oriya=Orija
Pashto, Pushto=Paszto
Persian=Perski
Polish=Polski
Portugues=Portugalski
Punjabi=Pend�abski
Quechua=Keczua
Rhaeto-Romance=Retroroma�ski
Romanian=Rumu�ski
Russian=Rosyjski
Samoan=Samoa�ski
Sanskrit=Sanskryt
Scots Gaelic=Szkocki Gealicki
Serbian=Serbski
Serbo-Croatian=Serbsko-Chorwacki
Sinhalese=Syngaleski
Slovak=S�owacki
Slovenian=S�owe�ski
Somali=Somalijski
Sundanese=Sundajski
Swedish=Szwedzki
Tamil=Tamilski
Tatar=Tatarski
Tibetan=Tybeta�ski
Tigrinya=Tigrinia
Turkmen=Turkme�ski
Uighur=Ujgurski
Ukrainian=Ukrai�ski
Uzbek=Uzbecki
Welsh=Walijski
Yiddish=Jidysz
Yoruba=Joruba
;
none (fastest, most ugly)=Brak (najszybciej, najbrzydziej)
approximate=Aproksymacja
full (slowest)=Pe�na (najwolniej)
bilinear (fast and not too bad)=Dwuliniowa (szybka i niez�a)
swscaler gaussian=SwScaler rozmycie Gauss'a
;
;    Zrzut obrazu
Select directory for storing images=Wska� folder przechowywania obraz�w
;
;   Ustawienia dekodera
Error=B��d
No quantization matrices available.=Brak matryc kwantyzacji.
mpeg1/2 decoder only=Tylko dekoder mpeg1/2
;
none=Brak
careful=Ostro�nie
compliant=Adaptacyjnie
aggressive=Agresywnie
very aggressive=Bardzo agresywnie
;
guess MVS=Zgadnij MVS
deblock=Deblocking
guess MVS + deblock=Zgadnij MVS + deblocking
;
;   Kolejkowanie i inne
constant=Sta�e
start=Start
;
;   Strumie� wyj�cia
closest=Najbli�szy
Unchecked: Use classic connection method.\nChecked: Use an advanced connection method that includes pixel aspect ratio (SAR) and interlacing information when connecting with the next filter (usually a video renderer).\nIndeterminate/grayed: Try advanced connection method first and fall back to classic connection method if it fails.\n\n(formerly called "Use overlay mixer")=Odznaczony: u�yj klasycznej metody ��czenia filtr�w.\nZaznaczony: u�yj zaawansowanej metody ��czenia, kt�ra uwzgl�dnia proporcje bok�w punktu (SAR) i informacje o przeplocie podczas pod��czania do nast�pnego filtru (zazwyczaj renderera video).\nCz�ciowo zaznaczony:  najpierw pr�buj u�y� zaawansowanej metody ��czenia filtr�w a je�li zawiedzie powr�� do metody klasycznej.\n\n(formalnie nazywane "Use overlay mixer")
Send interlacing related information obtained from the input stream or ffdshow's internal decoders to the next filter. Some filters (like video renderers) will use this information to deinterlace the video if neccessary.\nThis is just for informing the downstream filters - the actual result will depend purely on the implementation of these filters.\n\n(formerly called "HW deinterlacing")=Wy�lij powi�zan� informacje o przeplocie uzyskan� ze strumienia wej�ciowego b�d� wewn�trznego dekodera ffdshow do nast�pnego filtra. Niekt�re filtry (jak renderery video) u�yj� tej informacji do usuni�cia przeplotu je�li zajdzie taka konieczno��.\nOpcja ta s�u�y tylko do informowania filtr�w grafu - rzeczywisty rezultat b�dzie zale�a� ca�kowicie od implementacji tych filtr�w.\n\n(formalnie nazywane "HW deinterlacing")
Bob for video source\nWeave for film source\nIn most cases, Weave is the same as unchecked HW deinterlacing.=Bob dla �r�d�a video\nWeave dla �r�d�a filmu\nW wi�kszo�ci przypadk�w, Weave dzia�a tak samo jak odznaczony HW deinterlacing.
indeterminate state - connect to any filter, allows output format changes only if connected to supported filter.\n\nFilters known to support dynamic format change:\n  Overlay Mixer\n  VMR\n  VMR9\n  VobSub\n  Haali's Video Renderer\n  EVR\n  ffdshow=Cz�ciowo zaznaczony: po��cz z jakimkolwiek filtrem. Umo�liwia zmian� formatu wyj�ciowego tylko je�li po��czono z kompatybilnym filtrem.\n\nZnane filtry obs�uguj�ce dynamiczn� zmian� formatu:\n  Overlay Mixer\n  VMR\n  VMR9\n  VobSub\n  Haali's Video Renderer\n  EVR\n  ffdshow
Connect only to:\n  Overlay Mixer\n  VMR\n  VMR9\n  VobSub\n  Haali's Video Renderer\n  EVR\n  ffdshow=Po��cz tylko z:\n  Overlay Mixer\n  VMR\n  VMR9\n  VobSub\n  Haali's Video Renderer\n  EVR\n  ffdshow
;
; Konfiguracja dekodera audio
;   Kodeki
High accuracy mode is enabled for Tremor.=Tryb wysokiej dok�adno�ci jest w��czony dla Termor.
Adaptive Multi-Rate in 3gp files (AMR)=Adaptive Multi-Rate w plikach 3gp (AMR)
not WMA9 pro, voice or lossless=Nie obs�uguje WMA9 pro, voice oraz lossless
Windows Media Audio compatible decoder=Kompatybilny dekoder Windows Media Audio
Other ADPCM=Inne ADPCM
FLAC (Free Lossless Audio Codec);To play .flac files you also need a source filter.=Free Lossless Audio Codec; By odtwarza� pliki .flac potrzebujesz r�wnie� filtra �r�d�owego
TTA (Lossless Audio Codec);To play .tta files you also need a source filter.=TTA (Lossless Audio Codec); By odtwarza� pliki .tta potrzebujesz r�wnie� filtra �r�d�owego
DSP Group TrueSpeech compatible decoder=Kompatybilny dekoder DSP Group TrueSpeech
QDM2 compatible decoder (incomplete)=Kompatybilny dekoder QDM2 (niekompletne)
IMC compatible decoder=Kompatybilny dekoder IMC
ATRAC3 compatible decoder=Kompatybilny dekoder ATRAC3
Uncompressed=Nieskompresowany
;
Use SPDIF when AC3 output set=U�yj SPDIF gdy wybrano wyj�cie AC3
Check for DTS in WAV=Szukaj DTS w WAV
;
;   Informacje i CPU & OSD
Audio track=Strumie� audio
Sample frequency=Cz�stotliwo�� pr�bkowania
Number of channels=Liczba kana��w
Jitter=Jitter
Output speakers=G�o�niki
Sample format=Format pr�bki
Current input bitrate=Bie��cy bitrate wej�cia
;
;   Profile ustawie� \ ustawienia auto�adowania
on number of channels match=dla danej liczby kana��w
on sampling frequency match=dla danej cz�stotliwo�ci pr�bkowania
;
;    G�o�no��
mute=wycisz
;
;   Korektor
Select Winamp preset file=Otw�rz plik ustawie� Winamp'a
;
;   FIR Filter
lowpass=Dolnoprzepustowy
highpass=G�rnoprzepustowy
bandpass=Pasmowoprzepustowy
bandstop=Pasmowozaporowy
box=Prostok�tne
triangle=Tr�jk�tne
hamming=Hamming'a
hanning=Hanning'a
blackman=Blackman'a
flattop=P�askie
kaiser=Kaiser'a
;
;   Convolver
Select impulse file=Wska� plik impulsu
invalid=niepoprawny
;
Channel=Kana�
File=Plik
;
;   DSP Winampa
Winamp2 application directory, not plugin directory.=Folder instalacji Winamp'a - nie folder wtyczek.
Select Winamp 2 directory (not the plugins directory!)=Wska� folder instalacji Winamp'a (ale nie folder wtyczek!)
;
;   Resampler
libavcodec normal quality=libavcodec normalna jako��
libavcodec high quality=libavcodec wysoka jako��
libavcodec highest quality=libavcodec najwy�sza jako��
libsamplerate sinc high quality=libsamplerate sinc wysoka jako��
libsamplerate sinc medium quality=libsamplerate sinc �rednia jako��
libsamplerate sinc fastest=libsamplerate sinc najszybszy
higher than=wy�sza ni�
lower than=ni�sza ni�
;
;   Zamiana kana��w
front left=Przedni lewy
front center=Przedni centralny
front right=Przedni prawy
side left=Boczny lewy
side right=Boczny prawy
back left=Tylny lewy
back center=Tylny centralny
back right=Tylny prawy
;
;    Mikser
3/0/0 - 3 front=3/0/0 - 3 frontowe
2/0/1 - surround=2/0/1 - przestrzenne
3/0/1 - surround=3/0/1 - przestrzenne
2/0/2 - quadro=2/0/2 - kwadrofoniczne
3/0/2 - 5 channels=3/0/2 - 5 kana��w
3/2/1 - 6 channels=3/2/1 - 6 kana��w
3/2/2 - 7 channels=3/2/2 - 7 kana��w
same as input=Jak na wej�ciu
Head-related transfer function (HRTF)=Funkcja przenoszenia zwi�zana z g�ow� (HRTF)
headphone virtual spatialization=Symulacja g�o�nik�w w s�uchawkach
;
;    Strumie� wyj�cia audio
"not needed": no custom channel mapping="nie potrzeba": wy��czone niestandardowe mapowanie kana��w
any filter=Dowolny filtr
Useful for directly storing encoded ac3 to a file in graphedt with File Writer filter=Przydatne przy zapisie kodowanej �cie�ki AC3 bezpo�rednio do pliku w programie GraphEdit z filtrem File Writer
;
; Konfiguracja kodera video
Bitrate (kbps)=Bitrate (kb/s):
Quality=Jako��:
Quantizer=Kwantyzator:
No settings=Brak ustawie�
Size (Kbytes)=Rozmiar (kB):
;
one pass - average bitrate=1 przebieg - �redni bitrate
one pass - quality=1 przebieg - jako��
one pass - quantizer=1 przebieg - kwantyzator
two passes - 1st pass=2 przebiegi - 1-szy przebieg
two passes - 2nd pass int=2 przebiegi - 2-gi przebieg wewn�trzny
two passes - 2nd pass ext=2 przebiegi - 2-gi przebieg zewn�trzny
;
Load all=Wczytaj wszystko
Load page=Wczytaj okno dialogowe
Save all=Zapisz wszystko
Save page=Zapisz okno dialogowe
Manage presets...=Zarz�dzaj profilami...
;
Property=Atrybut
Value=Warto��
;
;   Og�lne
Store global headers in extradata=Przechowuj nag��wki globalne w dodatkowych danych
Greyscale=U�yj skali szaro�ci
Interlaced encoding=Koduj z przeplotem
Top field first (for intelaced encoding only)=Ustaw g�rne pole pierwsze (tylko dla kodowania z przeplotem)
Data partitioning=Partycjonuj dane
Unlimited motion vector=Nie ograniczaj wektora ruchu
Interlaced=U�yj przeplotu
Alternative inter vlc=Alternatywne inter vlc
Loop filter=Zap�tlone filtrowanie
Sliced structure=U�yj trybu o strukturze plastrowej
Generate access unit delimiters=Generuj separatory jednostek dost�pu
Each MB partition can independently select a reference frame=Ka�da partycja makrobloku mo�e niezale�nie wybra� klatk� referencyjn�
Transform coefficient thresholding on P-frames=Ograniczaj wsp�czynniki transformacji klatek P
Cabac=CABAC
Reserve space for SVCD scan offset user data=Zarezerwuj przestrze� dla danych nawigacji formatu SVCD
;
;   Szacowanie ruchu
simple=Prosty
fewest bits=Najmniej bit�w
rate distortion=Zniekszta�cenie tempa
;
adaptive with size 3=adaptacyjny o rozmiarze 3
adaptive with size 2=adaptacyjny o rozmiarze 2
experimental=eksperymentalny
size 1 diamond=normalny o rozmiarze 1
size 2 diamond=normalny o rozmiarze 2
size 3 diamond=normalny o rozmiarze 3
size 4 diamond=normalny o rozmiarze 4
size 5 diamond=normalny o rozmiarze 5
size 6 diamond=normalny o rozmiarze 6
;
never=Nigdy
after I frames=Tylko po klatce I
always=Zawsze
;
Very low=Bardzo niska
Low=Niska
Medium=�rednia
High=Wysoka
Very high=Bardzo wysoka
Ultra high=Najwy�sza
;
Off=Wy��czony
Mode decision=Tryb decyzyjny
Limited search=Ograniczona detekcja
Medium search=Umiarkowana detekcja
Full search=Pe�na detekcja
1 iteration of qpel on the winner=fullpel na wszystkich MB, 1 iteracja qpel na zwyci�zcy
2 iterations of qpel=fullpel na wszystkich MB, 2 iteracje qpel na zwyci�zcy
halfpel on all MB types, qpel on the winner=halfpel na wszystkich typach MB, qpel na zwyci�zcy
qpel on all=szybkie qpel na wszystkich typach MB
more iterations=wysoka jako�� qpel na wszystkich typach MB
;
spatial=Przestrzenne
temporal=Czasowe
auto=Automatyczne
;
diamond=Diament
hexagonal=Sze�ciok�t
;
;   Kwantyzacja
Custom=Niestandardowa
Modulated=Przekszta�cona
Modulated new=Przekszta�cona nowa
;
P frames=Klatki P
All frames=Wszystkie klatki
;
automatic=Automatycznie
disable=Wy��czony
;
8 bits=8 bit�w
9 bits=9 bit�w
10 bits=10 bit�w
11 bits=11 bit�w
;
; 2 przebiegi - 2-gi przebieg
%i%%: %i frame(s)=%i%%: %i klatek
quantizer:%i, percentage:%i=kwantyzator:%i, procent:%i
quantizer:%i, count:%i=kwantyzator:%i, liczba:%i
no simulation yet=Jeszcze nie symulowano
;
; 2 przebiegi - 2-gi przebieg/Inna kompresja
Low - cosine curve=Niska - krzywa cosinus
Medium - linear=�rednia - liniowa
High - sine curve=Wysoka - krzywa sinus
;
;   Statystyki
Select file for storing frames=Wska� plik do przechowywania klatek
Select file with stored encoding statistics=Wska� plik do przechowywania statystyk kodowania
;
Raw frames=Klatki nieskompresowane
OGG (works with Theora only)=OGM (dzia�a tylko z Theora)
Pixel aspect ratio=Proporcje bok�w punktu
Display aspect ratio=Proporcje bok�w obrazu
;
;   Strumie� wyj�cia
Square=Kwadrat
rate-distortion optimized MB types=optymalizacja zniekszta�cenia tempa MB
Flat=Macierz p�aska
JVT=Macierz JVT
Extended AC3 decoder (Dolby Digital Plus). Works only if AC3 decoding is enabled!=Dekoder Extended AC3 (Dolby Digital Plus). Dzia�a tylko, je�li dekodowanie AC3 jest w��czone!
Dolby TrueHD/MLP decoder. Works only if AC3 decoding is enabled!=Dekoder Dolby TrueHD/MLP. Dzia�a tylko, je�li dekodowanie AC3 jest w��czone!
ATSC A-52 (AC3) decoder=Dekoder ATSC A-52 (AC3)
DTS Coherent Acoustics stream decoder=Dekoder strumienia DTS Coherent Acoustics
FLAC (Free Lossless Audio Codec). To play .flac files you also need a source filter.=FLAC (Free Lossless Audio Codec). By odtwarza� pliki .flac potrzebujesz r�wnierz filtra �r�d�a.
TTA (Lossless Audio Codec). To play .tta files you also need a source filter.=TTA (Lossless Audio Codec). By odtwarza� pliki .tta potrzebujesz r�wnierz filtra �r�d�a.
Linear=Liniowa
Cubic=Sze�cienna
Top field first=G�rnego pola
Bottom field first=Dolnego pola
Unchecked: one-pass normalization will be performed.\n(this mode is used to reach the highest possible loudness\nwith minimum of possible artifacts)\n\nChecked: dynamic range compression will be performed.\n(quieter parts will be amplified more than louder parts,\nalso known as night mode)=Odznaczone: jedno pasmo normalizacji b�dzie przeprowadzone.\n(Ta metoda jest u�ywana by uzyska� mo�liwie najwi�ksz� mo�liw� g�o�no��\nz minimaln� ilo�ci� artefakt�w)\n\nZaznaczone: dynamiczne pasmo kompresji b�dzie przeprowadzone.\n(Cichsze cz�ci b�d� wzmacniane mocniej ni� g�o�niejsze cz�ci,\nznany jako "tryb nocny")
Enter logical expression with 'freq' variable and comparison and arithmetic operators,\nfor example "44100<=freq AND 48000<=freq".=Wprowad� logiczne wyra�enie z 'freq' (cz�stotliwo�ci�) oraz w�a�ciwym operatorem,\nna przyk�ad "44100<=freq AND 48000<=freq".
AC3 encoder currently supports the following sample rates: 32kHz and 48kHz.\nother sample rates should be resampled to one of the supported sample rates,\nthis can be done using the "Resample" filter.=Kodek AC3 aktualnie wspiera nast�puj�ce rodzaje sampli: 32kHz oraz 48kHz.\ninne rodzaje sampli powinny by� resamplowane do jednych z obs�ugiwanych format�w,\nmo�e to by� wykonane z u�yciem filtra "Resampler".
Force progressive=Wymu� progresywnie
Force interlace=Wymu� z przeplotem
Blu-ray and HD-TV use this.=Blu-ray oraz HD-TV u�ywaj� tego.
Use the information from the stream (H.264 only).\nIf it isn't available,\n  width > 1024 or height >=600: BT.709\n  width <=1024 and height < 600: BT.601=U�yj informacji ze strumienia (tylko H.264).\nJe�li nie jest dost�pne,\n  szeroko�� > 1024 or wysoko�� >=600: BT.709\n  szeroko�� <=1024 and wysoko�� < 600: BT.601
This setting also applies to YV12 <-> YUY2 conversion.=Ta opcja dodatkowo stosuje konwersj� YV12 <-> YUY2.
Use the information from the stream (H.264 only).\nIf it isn't available,\n  width > 1024 or height >=600: BT.709\n  width <=1024 and height < 600: BT.601=U�yj informacji ze strumienia (tylko H.264).\nJe�li nie jest dost�pna,\n  width > 1024 or height >=600: BT.709\n  width <=1024 and height < 600: BT.601
DVD, NTSC, PAL and SD-TV/videos use this.=DVD, NTSC, PAL oraz SD-TV/videos u�ywaj� tego.
Same as standard except H.264.\nH.264 has flag that indicates the range. Some people say the flag is sometimes wrong.=Taki sam jak "Standardowy" opr�cz H.264.\nH.264 b�dzie posiada� zmniejszony zakres.
Nearly all videos use this.\nFor JPEG, MJPEG and Fraps, ffdshow automatically uses full range.=Prawie wszystkie pliki u�ywaj� tego.\n Dla JPEG, MJPEG oraz Fraps, ffdshow automatycznie u�ywa pe�nego zakresu.
JPEG, MJPEG and Fraps sources usually use this=Zr�d�a JPEG, MJPEG and Fraps zwykle u�ywaj� tego
Most TV and Projectors use this.\nConsult the manual of your device.=Wi�kszo�� TV czy Projektor�w u�ywa tego.\nUwzgl�dnij informacje w instrukcji twojego urz�dzenia.
YCbCr <-> RGB conversion options=Opcje konwersji YCbCr <-> RGB
Force weave=Wymu� weave
Force bob=Wymu� bob
Auto: according to source flags, bob for interlaced frames, weave for progressive frames.\nForce weave: weave for each frame, regardless of source flags.\nForce bob: bob for each frame, regardless of source flags.\n\nNote: In most cases, Weave is the same as unchecked "Set interlace flag in output media type".=Auto: zgodnie z oznaczeniem w �r�dle, bob dla klatek z przeplotem, weave dla klatek progresywnych.\nWymu� weave: weave dla ka�dej klatki, bez wzgl�du na oznaczenie w �r�dle.\nWymu� bob: bob dla ka�dej klatki, bez wzgl�du na oznaczenie w �rodle.\n\nUwaga: W wi�kszo�ci przypadk�w, Weave jest tym samym czym odznaczenie opcji "Ustaw flag� przeplotu w strumieniu wyj�ciowym".
ffdshow searches subtitle files in the folders which are configured in the edit box above.\nFor video.avi, ffdshow searches video.utf, video.idx, video.sub,... and use the file which is found at the first time.\nEnumerate extensions in the order you like and separate them by semicolons.\n\nutf;idx;sub;srt;smi;rt;txt;ssa;aqt;mpl;usf is the default settings.=ffdshow szuka plik�w z napisami w folderze ustawionym w opcji wy�ej.\nDla plik�w video.avi, ffdshow szuka video.utf, video.idx, video.sub,... oraz u�ywa pliku kt�ry zosta� znaleziony jako pierwszy.\nWypisz rozszerzenia w porzadku jakim lubisz i oddziel je �rednikami.\n\nutf;idx;sub;srt;smi;rt;txt;ssa;aqt;mpl;usf jest domy�lnym ustawieniem.
Experimental, may give garbled subtitles.=Opcja eksperymentalna, mo�e powodowa� zniekszta�cenie napis�w.
Number of frames to buffer ahead=Ilo�� klatek do wcze�niejszego zbuforowania
Number of used frames to keep in buffer=Ilo�� u�ytych klatek do przetrzymania w buforze
original=Orginalny
simple MMX=Prosty MMX
curve=Krzywej
Solid fill=Sta�e wype�nienie
Shape XY=Kszta�towanie XY
Fast bilinear=Szybka dwuliniowa
Bilinear=Dwuliniowa
Bicubic=Dwusze�cienna
Point=Punktowa
Area=Obszarowa
Gauss=Gauss'a
Simple resize=Proste przetwarzanie
Linear interpolation=Liniowa interpolacja
Cubic interpolation=Sze�cienna interpolacja
H.264 and MPEG-1/2 decoder only=Tylko dekoder H.264 oraz MPEG-1/2
Checked: If soft telecine is detected, frames are flagged as progressive.\n\nYou may want to unckeck if you have interlaced TV.=Zaznaczone: Je�li �agodne Telekino zostanie wykryte, klatki b�d� traktowane jako progresywne.\n\nMo�esz to odznaczy�, je�li posiadasz TV z przeplotem.
equal number of frames, equal framerate=niezmienionej ilo�ci klatek + niezmienionej ilo�ci szybko�ci klatek
double number of frames, double framerate=podwojonej ilo�ci klatek + podwojonej ilo�ci szybko�ci klatek
double number of frames, equal framerate=podwojonej ilo�ci klatek + niezmienionej ilo�ci szybko�ci klatek
No motion estimation - blend images=Brak oszacowania ruchu - mieszaj obrazy
Current location only=Tylko aktualna lokacja
1 pixel motion, left & right=1 piksel ruchu, lewo & prawo
3x3 square=kwadrat 3x3
ctrl=Ctrl
alt=Alt
shift=Shift
page up=Page Up
page down=Page Down
Thai=Tajski
Vietnamese=Wietnamski
Arabic=Arabski
Chinese=Chi�ski
Greek=Grecki
Hebrew=Hebrajski
Sangho=Sango
Tajik=Tad�ycki
Turkish=Turecki
H264, AVC1, X264, VSSH (incomplete), DAVC, PAVC. ffmpeg-mt is multithreaded libavcodec (experimental).=H264, AVC1, X264, VSSH (niekompletne), DAVC, PAVC. ffmpeg-mt jest is wielow�tkowym libavcodec (opcja eksperymantalna).
Framerate doubler=Podwajacz ilo�ci klatek
Scan of bars will stop after this position. Set 0 to always scan for bars=Skaner zatrzyma si� po tym ustawieniu. Ustaw 0 by zawsze skanowa�
Tolerance when scanning bars=Tolorancja podczas skanowania
Set the delay in ms to rescan for the bars=Ustaw op�nienie w ms do ponownego przeskanowania

[101]
1=OK
2=Anuluj
3=&Zastosuj
1835=&Eksportuj ustawienia
1836=Wspom�

[182]
1162=Resetuj
1163=Pomoc
1723=Resetuj kolejno��

[115]
0=Kodeki

[116]
0=Ustawienia DirectShow
1285=Ustawienia DirectShow
1503=Priorytet:
1502=Wiele wyst�pie� ffdshow:
1935=Nie u�ywaj ffdshow w:
1973=Edytuj...
1970=U�ywaj ffdshow w:
1974=Edytuj...
2051=Wy�wietlaj okno dialogowe, gdy nieznana aplikacja pr�buje za�adowa� ffdshow

[295]
0=Mened�er kompatybilno�ci ffdshow
2041=Aplikacja "
2042=" podj�a pr�b� uruchomienia ffdshow.\nTo okno dialogowe zosta�o wy�wietlone dlatego, �e aplikacja nie jest uwzgl�dniona na bia�ej b�d� czarnej li�cie ffdshow.
2045=Nie u�ywaj ffdshow. (tylko tym razem)
2046=Nie u�ywaj ffdshow. (zawsze)
2047=U�yj ffdshow. (tylko tym razem)
2048=U�yj ffdshow. (zawsze)
2044=Raportuj ten plik exe anonimowo przez internet.
2049=Obja�nienie
2043=Nie pytaj mnie ponownie.

[224]
1972=Lista nazw plik�w wykonywalnych aplikacji kompatybilnych z ffdshow - jedna w ka�dym wierszu.
1975=Dodaj...
1976=Resetuj
2=Anuluj

[2020]
0=Informacje i CPU
1284=Informacje
1832=U�yj nast�puj�cych zestaw�w instrukcji SIMD (je�li s� obs�ugiwane przez CPU):
2212=Prze�lij dane do debuggera

[141]
0=OSD
1182=OSD
1774=Pozycja w poziomie:
1776=Pozycja w pionie:
1493=Zapisz do:
1491=U�ytkownika:
2218=Format tekstu dla u�ytkownika OSD:

[132]
0=Czcionka
1259=Czcionka:
1335=Autorozmiar
1827=Renderuj szybciej 
2081=Rozmyj
2060=Dodaj t�o napis�w
1116=Odst�py:
1120=Skala X:
2090=Skala Y:
2087=Pomi� skalowanie ASS/ASS2
2088=Popraw proporcje
1114=Kodowanie:
1108=Styl czcionki:
2065=Rozmiar, kolor i przezroczysto��
1110=Rozmiar:
1124=Kolor:
1981=Przezroczysto��:
2052=Cia�o:
2053=Zarys:
2054=Cie�:
1978=Typ cienia:

[136]
0=Ikony, �cie�ki i konfiguracja
1257=Ikony obszaru powiadomie�
2019=Zestaw ikon:
2016=Brak
2017=Nowszy
2018=Starszy
1074=Poka� informacje w etykiecie ikony
1073=Dodaj menu ikon do menu strumienia / wersji j�zykowej odtwarzacza
1258=Okna konfiguracyjne
1071=Zapami�taj pozycj�
1072=Pokazuj podpowiedzi
1293=J�zyk:
1259=�cie�ki
1143=Zestaw ikon\r\nPokazuje ikony w obszarze powiadomie�. Podw�jne klikni�cie wy�wietla okno konfiguracyjne, klikni�cie prawym klawiszem myszy wy�wietla proste menu ustawie�.\r\n\r\nZapami�taj pozycj�\r\nZapami�tuje pozycj� okna konfiguracyjnego (nie dzia�a w GraphEdit).

[143]
0=Klawisze skr�t�w
1202=Klawiatura
1329=Globalne klawisze skr�t�w
1330=Poka� informacje OSD po naci�ni�ciu klawisza
1416=Odleg�o�� skoku (sek):
1418=Odleg�o�� skoku (sek) - drugie polecenie:
1472=API zdalnego sterowania
1537=U�ytkownika:
1539=Obs�uguj zapytania klawiatury
1829=Eksportuj do pliku Grider'a...

[119]
0=Profile ustawie�
1278=Profile
1016=&Nowy
1156=&Otw�rz...
1155=Z&apisz jako...
1045=Zmie� &nazw�
1044=&Usu�
1051=Wczytaj ustawienia automatycznie
1080=Najpierw wczytaj z pliku
1157=Ustawienia automatycznego wczytywania...
1018=6

[171]
0=Ustawienia auto�adowania
2207=przy spe�nieniu jednego z warunk�w (OR),
2208=przy spe�nieniu wszystkich warunk�w (AND).
1211=dla danego rozmiaru klatki
1276=<=szeroko��<=
1277=<=wysoko��<=
1888=Do rozdzielenia wielu warto�ci u�yj ;
8=Zamknij

[233]
0=Poka� / ukryj filtry
1473=Dost�pne filtry:
1474=Widoczne filtry:

[102]
0=O programie
1849=Licencja
1839=Szczeg�y wersji

[193]
0=Szczeg�y wersji
2=Zamknij
; Konfiguracja dekodera video

[111]
1164=&Przetw�rz ca�y obraz
1167=&Tylko praw� po�ow�
1162=Resetuj
1163=Pomo&c
1723=Resetuj kolejno��

[134]
0=Przycinanie
1137=Przycinanie i powi�kszanie:
1138=Powi�ksz
1139=Przytnij
1105=Powi�kszenie w poziomie:
1107=Powi�kszenie w pionie:
1140=Blokuj
1252=G�ra:
1254=Lewo:
1255=Prawo:
1256=D�:
2091=Autoprzycinanie:
2098=Pionowo
2099=Poziomo
2100=Pionowo i poziomo
2094=Tolerancja:
2096=Od�wie�anie (ms):
2101=Nie skanuj po (ms):
1109=Powi�kszenie
1111=Pozycja w poziomie
1113=Pozycja w pionie
1143=Przytnij\r\nSzerko�� i wysoko�� przyci�tego obszaru jest zaokr�glana do wielokrotno�ci o�miu. Je�li podasz niew�a�ciw� warto��, pole edycyjne zmieni t�o na czerwone a warto�� nie zostanie zapisana. U�ywaj�c tego filtra prawdopodobnie b�dziesz musia� poprawi� proporcje bok�w obrazu.

[140]
0=Usuwanie przeplotu
1167=Usuwanie przeplotu
1523=Metoda:
1209=Zamie� pola
2220=Przetwarzaj klatki oznaczone jako progresywne

[242]
0=Usuwanie logo
1552=Usuwanie logo
1574=Tylko luminancja
1555=Waga X-Y:
1542=Lewo:
1544=G�ra:
1551=Tryb:
1546=Szeroko��:
1548=Wysoko��:
1558=Kolor:
1854=Obraz logo:
1559=Wczytaj profil filtra:
1562=Zaawansowane:

[120]
0=Przetwarzanie
1073=Przetwarzanie
1027=Ustawienia standardowe
1008=Ustawienia automatyczne
1272=Deblock (poziomo)
1273=Deblock (pionowo)
1028=Ustawienia r�czne
1270=Luminancja
1271=Chroma
1158=Si�a przetwarzania:
1160=Metoda przetwarzania:
1534=Precyzyjny Deblocking
1275=Popraw poziom:
1035=Luminancji
1038=Pe�en zakres
1457=Szybki Deblocking SPP
1456=Deblocking SPP
1459=�agodny pr�g
1328=Najpierw Nic's
1242=Zasi�g X:
1243=Zasi�g Y:
1238=MPlayer
1274=Dering

[125]
0=W�a�ciwo�ci obrazu
1072=W�a�ciwo�ci obrazu
1017=Wzmocnienie luminancji (kontrast):
1932=Efekt "Scanline":
1018=Przesuni�cie luminancji (jasno��):
1037=Korekcja gamma:
1038=Korekcja gamma RGB:
1025=Odcie�:
1026=Nasycenie:
1781=Koloryzuj:
1787=Tylko chrominancja
1782=Si�a:
1830=Popraw poziom luminancji
1831=Pe�en zakres

[270]
1941=Pr�g:

[142]
0=Poziomy
1170=Poziomy
1707=Tryb:
1179=Modyfikuj tylko luminancje
1184=Poka� histogram
1185=Pe�en zakres
1291=Wej�cie
1909=Automatycznie
1267=Wyj�cie
1181=Korekcja gamma:
1189=Rozk�ad funkcji:
1933=Za�aduj krzyw�...
2103=Maks. delta Y:
2106=Pr�g Y:
2109=Czasowy Y:

[137]
0=Przesuni�cie
1148=Przesuni�cie
1149=Przesuni�cie poziome luminancji:
1151=Przesuni�cie pionowe luminancji:
1153=Przesuni�cie poziome chrominancji:
1120=Przesuni�cie pionowe chrominancji:
1939=Przerzu� w pionie
1940=Przerzu� w poziomie
1143=Zmienia pozycj� plan�w luminancji i chrominancji.\r\nMo�na u�y� do korekcji z�ych uj��.

[128]
0=Rozmywanie
1134=Rozmywanie i odszumianie
1136=Zmi�kczanie:
1137=Wyg�adzanie czasowe:
1232=Uwzgl�dniaj kolory
1138=Wyg�adzanie luminancji:
1139=Wyg�adzanie chrominancji:
1140=Odszumianie stopniowe:
1141=Czasowy odszumiacz MPlayer'a:
1142=swscaler rozmycie Gauss'a
1415=Wysoka jako��

[127]
0=Wyostrzanie
1065=Wyostrzanie
1216=Wysoka jako��
1215=Tylko maska
1217=Wysoka jako�� filtracji blok�w
1019=Si�a:
1021=Zasi�g:
1023=Si�a wyostrzania blok�w:
1143=xsharpen\r\nFiltr ten wykonuje subtelne ale przydatne wyostrzanie. Zasada jego dzia�ania polega na wy�wietleniu ma�ego okna na klatce i ka�dym centralnym pikselu, kt�ry zosta� pomini�ty (zale�nie od ustawienia zakresu), albo zmapowany do najja�niejszego lub najciemniejszego piksela w oknie, zale�nie od tego kt�ry jest bli�ej piksela centralnego. Je�li zmapowany jest piksel centralny, jego przezroczysto�� alfa przyjmuje warto�� zale�n� od oryginalnej warto�ci piksela zgodnie z ustawieniami si�y. Rezultatem jest efekt wyostrzenia, kt�ry ponadto �e nie wzmacnia szumu, redukuje go.\r\n\r\nunsharp masking\r\nFiltr ten wykorzystuje dobrze znan� technik� uwydatnienia kontrastu i wyostrzenia, nazywan� unsharp masking. Zasada jego dzia�ania polega na utworzeniu rozmytej kopii oryginalnego obrazu i odj�ciu go od obrazu oryginalnego. Obraz wynikowy zyskuje wzmocnienie kontrastu wok� szczeg��w umieszczonych na obrazie oryginalnym. Rezultatem jest bardzo przyjemny efekt wyostrzenia, kt�ry jest lepszy od prostego wyostrzania z j�drem splotu b�d� wysoko-pasmowym wzmocnieniem.\r\n\r\nmsharpen\r\nWyostrza wa�ne kraw�dzie obrazu bez wzmacniania szumu. Filtr wykrywa kraw�dzie a potem u�ywa j�dra wyostrzaj�cego w obszarze kraw�dzi.\r\n\r\nasharp\r\nJeden z najlepszych filtr�w wyostrzaj�cych, kt�ry daje doskona�� jako�� obrazu wraz z w��czonym filtrem Przetwarzanie. Najlepsz� jako�� uzyskamy u�ywaj�c go z obrazem niskiej i �redniej jako�ci.\r\n\r\nswscaler\r\nJeden z najlepszych filtr�w wyostrzaj�cych, kt�ry daje doskona�� jako�� obrazu wraz z w��czonym filtrem Przetwarzanie. Najlepsz� jako�� uzyskamy u�ywaj�c go z obrazem wysokiej jako�ci.\r\n\r\nOpis zosta� skopiowany z oryginalnej dokumentacji filtr�w AviSynth i VirtualDub\r\nprawa autorskie (C) Donald Graft

[181]
1339=oryginalny warpsharp ffdshow
1341=Tryb chrominancji:
1343=Tryb rozmywania:
1019=G��bia:
1021=Zasi�g:
1023=Rozmywanie:
1143=aWarpSharp implementuje oryginalne wyostrzanie wysokiej jako�ci. "Oryginalne" oznacza, �e algorytm r�ni si� w pewnym stopniu od innych filtr�w wyostrzaj�cych. Kod jest w pe�ni zoptymalizowany dla iSSE z wysok� dok�adno�ci�.\r\n\r\nMarc Fauconneau
0=WarpSharp
1338=WarpSharp

[176]
0=Filtr DScaler
1308=Filtr DScaler
1309=Filtr:

[126]
0=Nak�adanie szumu
1038=Nak�adanie szumu
1067=Stary algorytm szumu
1068=Nowy algorytm szumu (avih)
1069=Algorytm MPlayer'a
1232=U�redniony
1039=R�wnomierny
1231=Wzorzysty
1041=Luminancja - si�a szumu:
1049=Chrominancja - si�a szumu:
1050=Migotanie:
1051=Potrz�sanie:
1052=Pionowe linie:
1054=Zadrapania:

[133]
0=Zmiana rozmiaru
1083=Zmiana rozmiaru:
1986=Okre�l rozmiar poziomy i pionowy
1987=Okre�l rozmiar poziomy
1285=Rozmiar:
1186=Okre�l proporcje bok�w obrazu
1286=Proporcje:
1187=Popraw do wielokrotno�ci:
1540=Mn� przez:
2086=Zmie� do rozmiaru pulpitu
1189=Zmie� je�li...
1191=Zmie� je�li liczba pikseli jest...
1188=Zmieniaj zawsze
1988=Zmie� proporcje bok�w punktu
2084=Proporcje bok�w punktu:
1289=Proporcje bok�w obrazu:
1100=Nie koryguj
1101=Blokuj
1102=Ustaw r�cznie:
1234=Proporcje nak�adki:
1288=Y
1287=X

[261]
0=Ramki
1857=Ramki:
1860=Wewn�trzne
1861=Zewn�trzne
1858=Procent
1859=Pikseli
1862=Poziomo:
1199=Blokuj
1863=Pionowo:
2067=Po�o�enie obrazu
2068=Lewo
2069=Prawo
2079=Poziomo:
2070=G�ra
2071=D�
2080=Pionowo:
2209=Jasno��:

[138]
0=Ustawienia
1282=Ustawienia zmiany rozmiaru
1285=Metoda lumy:
1892=Blokuj
1286=Metoda chromy:
1098=Rozmywanie luminancji:
1099=Rozmywanie chrominancji:
1019=Wyostrzanie luminancji:
1020=Wyostrzanie chrominancji:
1021=Parametr:
1023=Parametr:
1100=Poziome odkszta�cenie:
1022=Pionowe odkszta�cenie:
1360=Uwzgl�dnij przeplot
1953=Zaokr�glaj precyzyjnie 
1143=Algorytmy zmiany rozmiaru uszeregowane wed�ug jako�ci przetwarzania:\r\nSpline > Lanczos (10.00) >  Dwusze�cienna (-0.60) > Dwuliniowa > Szybka dwuliniowa > Punktowa > Brak\r\n\r\nRozmywanie - rozmywa obraz podczas zmiany rozmiaru, dzia�a niezale�nie od filtr�w rozmywania,\r\nWyostrzanie - wyostrza obraz podczas zmiany rozmiaru, dzia�a niezale�nie od filtr�w wyostrzania,\r\n\r\nUwzgl�dnij przeplot:\r\nodznaczone - klatki traktowane s� jak progresywne,\r\nzaznaczone - klatki traktowane s� jak z przeplotem,\r\ncz�ciowo zaznaczone - decyduje typ klatki na wej�ciu (u�ywane przy przetwarzaniu MPEG2 video).\r\n\r\nZaokr�glaj precyzyjnie :\r\nodznaczone - czasami widoczne s� poziome linie,\r\nzaznaczone - wysoka jako��, wolniejszy w niekt�rych przypadkach.

[177]
0=Korekcja perspektywy
1317=Korekcja perspektywy
1321=Zmie� obszar na prostok�tny
1319=Interpolacja:
1143=To nie jest finalna wersja filtru - na obrazie mog� pojawi� si� czarne kropki.

[180]
2021=Dodaj �r�d�o obrazu ffdshow
2024=Przestrzenie kolor�w:
2029=Bufor w prz�d/ty�:
2032=U�yj bie��cy
2033=Otw�rz...
2034=Zapisz...
2023=3:2 Pulldown:

[139]
0=Wizualizacje
1337=Wizualizacje
1074=Poka� wektory przesuni�cia
1075=Kwantyzatory
1357=Graf
1143=Spr�buj tego - wygl�da ciekawie.

[179]
1325=Wsp�czynniki
1919=Kwantyzacja H.263
1922=Kwantyzacja MPEG
1917=Matryca kwantyzacji
1920=Kwantyzator:
1143=Filtr ten jest eksperymentalnym filtrem, kt�ry dla ka�dego bloku 8x8 wykonuje dyskretn� transformat� kosinusow� (DCT), skaluje wybran� cz�stotliwo�� i odwraca proces wykonuj�c odwrotn� dyskretn� transformat� kosinusow� (IDCT).\r\n\r\nPrawa autorskie (C) 2002 Tom Barry - trbarry@trbarry.com
1324=Dyskretna transformata kosinusowa

[267]
0=Bie��ce matryce kwantyzacji
8=Zamknij

[225]
1840=Matryca intra:
1763=Matryca inter:
1828=Otw�rz matryc�...
1829=Zapisz matryc�...

[255]
0=Nak�adanie bitmapy
1798=Nak�adanie bitmapy
1799=Nazwa pliku:
1802=Pozycja w poziomie:
1803=Pozycja w pionie:
1810=Wyr�wnanie:
1361=Tryb:
1807=Przezroczysto��:

[113]
0=Napisy
1105=Napisy
1279=Szukaj w:
1837=Poszukiwania heurystyczne
1968=Priorytety rozszerze�:
1183=Plik:
1414=�led� zmiany w pliku
1244=Prze�aduj
1787=Akceptuj osadzone napisy
1789=Akceptuj napisy SSA, ASS i ASS2 (eksperymentalne)
1788=Dekoduj napisy Closed Caption
1122=Pozycja w poziomie:
1126=Pozycja w pionie:
1358=Letterbox:
1280=Przesu� o:
1364=Kasuj
1281=Szybko��:
1360=Wyr�wnanie:
1683=Stereoskopowo
1722=Paralaksa:
2226=Ustawienia ASS/SSA
1790=Wsparcie dla znacznik�w SSA w plikach SRT oraz znacznik�w HTML w plikach SSA

[254]
0=Tekst
1793=Tekst napis�w
1571=Dziel d�ugie wiersze napis�w:
1723=Interlinia:
1572=Buforuj napisy o tym samych czasach
1836=Marginesy po bokach:
1775=pikseli
1767=Wy�wietlaj:
1772=Przez minimum:
1794=Poprawki:
1787=Zamie� podw�jne ' na " a podw�jne "" na "
1788=Spr�buj poprawi� I i l
1790=Spr�buj poprawi� znaki interpunkcyjne (?. -> ? ; !. -> ! itp.)
1795=Spr�buj poprawi� ortografi�
1791=Spr�buj poprawi� kapitaliki
1792=Usu� zb�dne odst�py pomi�dzy cyframi
1798=Usu� napisy dla upo�ledzonych s�uchowo

[250]
1725=W��cz
1726=Preferowane j�zyki:
1728=Bie��cy j�zyk:
1727=Metoda wyg�adzania:
1730=Rozmywanie Gauss'a:
1729=Skala:
1796=Zachowaj ustawienia pozycji z zak�adki Napisy
0=VobSub
1724=VobSub

[172]
0=Zrzut obrazu
1216=Zrzut obrazu
1223=Wszystkie klatki
1224=Jedna klatka:
1226=Zakres:
1740=Zrzucaj co:
1741=klatek
1232=Folder:
1261=Prefix:
1263=Ilo�� cyfr w nazwie:
1262=Format:
1228=&Zrzu� obraz
1230=Jako��:

[173]
0=Nak�adka
1235=Ustawienia nak�adki
1236=Jasno��:
1137=Kontrast:
1138=Odcie�:
1139=Nasycenie:
1140=Ostro��:
1141=Gamma:
1143=Dzia�a tylko, gdy zaznaczono opcj� "Ustaw proporcje bok�w punktu w strumieniu wyj�ciowym" w zak�adce "Strumie� wyj�cia" i gdy sprz�t j� wspiera.\r\n\r\nKompatybilne z rendererami overlay mixer oraz VMR9 w trybie windowed.

[118]
0=Ustawienia dekodera
1283=Ustawienia libavcodec
1045=IDCT
1916=Bie��ce matryce kwantyzacji
1572=Ilo�� w�tk�w dekodera:
1314=Dekoduj w skali szaro�ci
1047=Pomi� b��dy kompresji:
1307=Autodetekcja
1309=B��d przeplotu starszego Xvid'a
1313=B��d quarterpixel Xvid i DivX
1315=Kraw�d�
1542=Czu�o�� detekcji b��d�w:
1544=Metoda ukrywania b��d�w:
1946=Ustawienia wydajno�ci
1943=Porzu� klatk� przy op�nieniu:
1947=Pomi� deblocking H264 przy op�nieniu:
1308=Starsze pliki lavc msmpeg4
2248=Wykryj �agodne Telekino oraz �redni czas klatki
1316=B��d przeplotu chromy w DivX

[121]
0=Kolejkowanie i inne
1944=Kolejkuj pr�bki na wyj�ciu
1958=Kolejkuj tylko w:
2206=W��cz kolejkowanie w VMR9-YV12
1365=Inne ustawienia
1268=Op�nienie video:
1764=Koniec
1550=Ustaw przeplot na wej�ciu je�li wysoko�� >
1552=pikseli
1143=Kolejkuj pr�bki na wyj�ciu\r\nZadaniem kolejkowania jest zmniejszenie ilo�ci porzucanych klatek. U�ycie tej opcji daje efekty gdy obci��enie CPU jest du�e i porzucanych jest kilka klatek na sekund�. Je�li CPU zako�czy prac� wcze�niej to zaoszcz�dzony w ten spos�b jego czas zostanie u�yty w przypadku pojawienia si� ewentualnego op�nienia. Renderer video wykonywany jest przez inny w�tek, dlatego efekt jest lepszy je�li posiadasz Pentium4HT albo dwurdzeniowy CPU.\r\n\r\nKolejkuj tylko w\r\nKolejkowanie jest domy�lnie wy��czone ze wzgl�du na problemy zwi�zane ze stabilno�ci� w aplikacjach innych ni� Media Player Classic. Je�li chcesz spr�bowa�, odznacz lub dodaj nazwy plik�w wykonywalnych aplikacji video rozdzielone �rednikiem.\r\n\r\nW��cz kolejkowanie w VMR9-YV12\r\nKolejkowanie w VMR9-YV12 nie dzia�a z niekt�rymi zintegrowanymi kartami graficznymi Intel'a.\r\n\r\nInne ustawienia\r\nOp�nienie video: mo�esz spr�bowa� tej opcji je�li �cie�ki audio i video s� nie zsynchronizowane.

[231]
0=Strumie� wyj�cia
1284=Obs�ugiwane wyj�ciowe przestrzenie kolor�w
1052=Wysoka jako�� konwersji YV12 do RGB
1036=Wybierz najbli�ej pasuj�c� przestrze� kolor�w
1031=Ustaw proporcje bok�w punktu w strumieniu wyj�ciowym
1033=Ustaw flag� przeplotu w strumieniu wyj�ciowym
1966=Metoda:
1017=Umo�liwiaj zmian� formatu wyj�ciowego podczas odtwarzania
1034=��cz tylko z kompatybilnymi filtrami
1910=Profil:
1016=Przerzu� w pionie
2233=Zacznij od:

[2112]
0=Konwersja RGB
2123=Specyfikacja YCbCr:
2122=Kontrast:
2124=Standardowy ( Y : 16-235, chroma : 16-240 )
2125=Pe�en zakres ( Y : 0-255, chroma : 1-255 )
2126=Niestandardowy
2118=Odci�cie czerni:
2119=Odci�cie bieli:
2121=Sprz� chrominancje
2120=Odci�cie chrominancji:
1052=Wysoka jako�� konwersji YV12 do RGB
2241=Metoda
2250=Wyj�ciowe lewele:
2251=Monitor komputera  (RGB: 0 - 255)
2252=TV / Projektor  (RGB: 16 - 235)
2243=Z przeplotem lub progresywna:

[288]
0=1. O dekoderze video ffdshow\r\n\r\nffdshow to oprogramowanie o otwartym kodzie �r�d�owym w sk�ad kt�rego wchodzi dekoder DirectShow i kodek VFW. S�u�y ono do szybkiego dekodowania materia�u audio i video zapisanego w r�nych formatach.\r\n\r\nffdshow posiada du�� ilo�� filtr�w przetwarzaj�cych, kt�re opcjonalnie mog� zosta� w��czone by polepszy� jako�� strumieni wyj�ciowych audio i video. Niekt�re z tych filtr�w to: usuwanie blok�w, zmiana rozmiaru, korekcja proporcji obrazu, wyostrzanie, wy�wietlanie napis�w, usuwanie przeplotu, przycinanie i korekcja barwy.\r\n\r\n2. Cechy\r\n\r\n- szybka dekompresja video z u�yciem kodu zoptymalizowanego dla instrukcji SIMD: MMX, SSE, SSE2, SSE3 i 3DNow!\r\n- obs�uga du�ej ilo�ci format�w video: DivX, Xvid, H.264/AVC, Theora, MPEG1/2, VP3/5/6, FLV1/4, SVQ1/3 i wielu innych,\r\n- sprz�towa obs�uga usuwania przeplotu z meteria�u nieskompresowanego,\r\n- potrafi zachowywa� si� jak natywny filtr przetwarzaj�cy do przetwarzania wyj�ciowego materia�u nieskompresowanego innych dekoder�w,\r\n- przetwarzanie obrazu umo�liwiaj�ce polepszenie jako�ci odtwarzania video,\r\n- automatyczne ustawienia jako�ci: automatycznie redukuje poziom przetwarzania w przypadku du�ego obci��enia mikroprocesora,\r\n- korekcja barwy, nasycenia i luminancji (zoptymalizowane dla MMX),\r\n- ikona obszaru powiadomie� z menu i szybkim dost�pem do okna konfiguracyjnego,\r\n- wielow�tkowa zmiana rozmiaru: szybsza zmiana rozmiaru na wielordzeniowych mikroprocesorach,\r\n- obs�uga napis�w,\r\n- funkcjonalno�� "czarnej" i "bia�ej" listy umo�liwiaj�ca konfiguracj� uruchamiania ffdshow w okre�lonych aplikacjach,\r\n- ca�kowicie wolne oprogramowanie: ffdshow jest dystrybuowany na zasadach Powszechnej Licencji Publicznej GPL.\r\n\r\n3. ffdshow-tryouts\r\n\r\nffdshow pierwotnie zosta� opracowany przez Milan'a Cutka. Od czasu gdy Milan Cutka zaprzesta� aktualizowania w 2006 roku, uruchomili�my nowy projekt "ffdshow-tryouts".\r\n\r\n4. Odno�niki\r\n\r\nffdshow-tryouts:\r\nhttp://ffdshow-tryout.sourceforge.net/\r\nhttp://sourceforge.net/project/showfiles.php?group_id=173941\r\n\r\nffdshow (stare):\r\nhttp://ffdshow.sourceforge.net/tikiwiki/\r\nhttp://sourceforge.net/projects/ffdshow/\r\n\r\nXvid:\r\nhttp://www.xvid.org/\r\n\r\nFFmpeg:\r\nhttp://ffmpeg.mplayerhq.hu/\r\n\r\nlibmpeg2:\r\nhttp://libmpeg2.sourceforge.net/\r\n\r\nMPlayer:\r\nhttp://www.mplayerhq.hu/\r\n\r\nkod xsharpen, unsharp mask, msharpen, barwa i nasycenie\r\nhttp://sauron.mordor.net/dgraft/index.html\r\n\r\nDoom9:\r\nhttp://forum.doom9.org/showthread.php?t=120465\r\n\r\nWikipedia, wolna encyklopedia:\r\nhttp://en.wikipedia.org/wiki/Ffdshow\r\n\r\n5. Kopiowanie\r\n\r\nWszystkie u�yte �r�d�a (z wyj�tkiem planu detekcji wykorzystania mikroprocesora) jak i sam ffdshow s� dystrybuowane na zasadach Powszechnej Licencji Publicznej GPL. Zobacz plik copying.txt.\r\n\r\nLokalizacja:\r\nPiotr Sok�, Radzio, Virtual_ManPL <ffdshow-polish@googlegroups.com>
; Konfiguracja dekodera audio

[248]
0=Strumienie
1709=Strumienie
1683=W��cz
1710=Strumie�:

[259]
0=Przetwarzanie
1579=Przetwarzanie obs�ugiwanych format�w pr�bek audio:
1580=16 bit sta�oprzecinkowy
1585=32 bit sta�oprzecinkowy
1586=32 bit zmiennoprzecinkowy
1578=Konwersja formatu zmiennoprzecinkowego na sta�oprzecinkowy

[244]
0=Dekoder Dolby
1657=Dekoder Dolby
1656=Op�nienie tylnych kana��w:

[188]
0=G�o�no��
1377=G�o�no��
1937=U�yj skali decybelowej
1375=Regulacja g�o�no�ci:
1650=P
1651=TylnyL
1652=TylnyP
2194=BoczL
2195=BoczP
1653=LFE
1922=W
1924=W
1926=W
1928=W
1930=W
2202=W
2201=W
1932=W
1457=Normalizuj
1637=Maksymalne wzmocnienie:
1957=Resetuj podczas szukania
1956=Bufor:
1641=Aktualnie:
1683=Pokazuj aktualny poziom g�o�no�ci
1603=TylnyL
1604=TylnyP
1602=P
2196=BoczL
2197=BoczP
2219=Odzyskaj g�o�no��

[189]
0=Korektor graficzny
1378=Korektor graficzny
1814=Wczytaj ustawienia Winamp'a...
1465=dB
1466=dB

[246]
0=Filtr SOI
1686=Filtr o sko�czonej odpowiedzi impulsowej
1688=Rz�d filtru:
1700=Maks. cz�stotliwo��:
1690=Typ filtra:
1696=Cz�st. graniczna:
1698=Szeroko�� pasma:
1692=Okno:
1683=Poka� widmo
1143=W przetwarzaniu sygna�u wyst�puje wiele przypadk�w, w kt�rych sygna� wej�ciowy do systemu zawiera dodatkow� niepotrzebn� zawarto�� oraz szum, kt�ry mo�e obni�y� jako�� po��danego fragmentu. Dlatego w takich przypadkach mo�emy usun�� lub przefiltrowa� niepotrzebny sample. Dla przyk�adu, w systemach telefonicznych nie ma potrzeby by transmitowa� bardzo wysokich cz�stotliwo�ci, gdy� wi�kszo�� mowy wypada w przedziale od 400 do 3.400 Hz. Dlatego wszystkie cz�stotliwo�ci powy�ej lub poni�ej tego przedzia�u zostaj� odfiltrowane. Zakres cz�stotliwo�ci pomi�dzy 400 i 3.400 Hz, kt�ry nie zosta� odfiltrowany znany jest jako pasmo przepustowe, a cz�stotliwo�� kt�ra zosta�a zablokowana znana jest jako stopband.\r\n\r\nSOI, Filtr o sko�czonej odpowiedzi impulsowej jest jednym z g��wnych typ�w filtr�w u�ywanych w Cyfrowym Przetwarzaniu Sygna��w. O filtrach SOI m�wi si�, �e s� sko�czone, poniewa� nie posiadaj� �adnego sprz�enia zwrotnego. Zatem, je�li wy�lesz jeden pojedynczy impuls przez system, to wyj�cie b�dzie niezmiennie darzy� do zera tak szybko jak impuls biegnie przez filtr.

[262]
1881=Plik impulsu:
1905=R�czne mapowanie kana��w:
1902=Wybierz plik...
1903=Wyczy��
1893=Regulacja poziomu:
1891=Automatyczna regulacja
1889=Si�a miksowania:

[247]
0=Redukcja szumu
1706=Redukcja szumu
1704=Pr�g:

[190]
0=DSP Winamp'a
1400=DSP Winamp'a
1401=Wska� folder instalacji Winamp'a...
1404=Konfiguruj
1989=Przetwarzaj d�wi�k wielokana�owy

[236]
1485=Rozmiar pomieszczenia:
1487=T�umienie:
1490=Poziom wilgotno�ci:
1019=Poziom sucho�ci:
1038=Szeroko��:

[249]
0=Krystaliczno��
1711=Krystaliczno��
1712=Poszerzenie pasma:
1714=Filtr g�rnoprzepustowy:
1716=Wzmocnienie harmonicznych:
1718=G�o�no�� echa:
1720=Sprz�enie echa:
1722=Uwydatnienie stereo:

[237]
0=Resampler
1497=Resampler
1498=Resampluj do:
1499=Tryb:
1875=Resampluj zawsze
1876=Resampluj je�li cz�stotliwo�� pr�bkowania jest...
1143=Kliknij "Zastosuj" albo "OK", by zmieni� cz�stotliwo�� pr�bkowania.

[245]
0=Op�nienie
1676=Op�nienie
1658=Przedni lewy:
1663=Przedni centralny:
1666=Przedni prawy:
2178=Boczny lewy:
2181=Boczny prawy:
1669=Tylny lewy:
2184=Tylny centralny:
1672=Tylny prawy:
1675=LFE:

[252]
0=Emisja LFE
1733=Emisja LFE
1734=Cz�stotliwo�� graniczna:
1736=Wzmocnienie:
1741=Usu� niskie cz�stotliwo�ci dodane do LFE z lewego i prawego kana�u

[253]
0=Zamiana kana��w
1763=Zamiana kana��w
1749=Przedni lewy
1748=Przedni centralny
1747=Przedni prawy
2188=Boczny lewy
2191=Boczny prawy
1746=Tylny lewy
1670=Tylny centralny
1745=Tylny prawy
1744=LFE
1143=Kana�y mog� by� tak�e zamienione przy pomocy filtra Mikser, ale ten jest szybszy.

[191]
0=Mikser
1405=Mikser
1406=Konfiguracja g�o�nik�w:
1636=Dostosuj macierz:
1586=Normalizuj macierz
1596=P
2172=BoczL
2173=BoczP
1597=TylnyL
2176=TylnyC
1598=TylnyP
1635=P
2174=BoczL
2175=BoczP
1632=TylnyL
2177=TylnyC
1633=TylnyP
1588=Ustawienia g�osu
1637=Uwydatnij stereo
1701=G�os:
1702=Otoczenie:
1685=Rozpi�to�� s�uchawek:

[243]
0=Strumie� wyj�cia
1573=Obs�ugiwane formaty pr�bek wyj�ciowych:
1574=16 bit sta�oprzecinkowy
1575=24 bit sta�oprzecinkowy
1576=32 bit sta�oprzecinkowy
1577=32 bit zmiennoprzecinkowy
1587=AC3 (S/PDIF tryb kodowania)
1985=Koduj tylko strumienie wielokana�owe
1845=Po��cz z filtrem:
1846=Zastosuj jedynie do wyj�cia S/PDIF
1984=Urz�dzenie wielokana�owe:
1811=Nie u�ywaj nag��wka WAVEFORMATEXTENSIBLE, gdy nie ma potrzeby
1813=Zezw�l na wyj�cie bezpo�rednio do pliku
1143=Dla lepszej wydajno�ci na wolniejszych komputerach b�d� w przypadku niekompatybilnych sterownik�w, odznacz wszystko z wyj�tkiem opcji "16 bit sta�oprzecinkowy".\r\nOpcja LPCM jest przeznaczona do pod��czania filtr�w dekoduj�cych audio, jak np. filtr Cyberlink'a.
2234=Przej�cie przez S/PDIF oraz HDMI:

[289]
0=1. O dekoderze audio ffdshow\r\n\r\nffdshow to oprogramowanie o otwartym kodzie �r�d�owym w sk�ad kt�rego wchodzi dekoder DirectShow i kodek VFW. S�u�y ono do szybkiego dekodowania materia�u audio i video zapisanego w r�nych formatach.\r\n\r\nPosiada mo�liwo�� przetwarzania strumieni audio przy pomocy takich filtr�w jak korektor graficzny, g�o�no��, dekoder Dolby, op�nienie, DSP Winamp'a i innych.\r\n\r\n2. Cechy\r\n\r\n- obs�uga du�ej ilo�ci format�w audio: AC3, AAC, DTS, MP1/2/3, Vorbis, LPCM, TTA, QDM2, ADPCM, IMC,  ATRAC3 i wielu innych,\r\n- dekoder Dolby,\r\n- filtry audio: korektor graficzny, g�o�no��, op�nienie, mikser i convolver,\r\n- wielokana�owe przetwarzanie przez komponenty Winamp'a,\r\n- obs�uga wyj�cia SPDIF.\r\n\r\n3. ffdshow-tryouts\r\n\r\nffdshow pierwotnie zosta� opracowany przez Milan'a Cutka. Od czasu gdy Milan Cutka zaprzesta� aktualizowania w 2006 roku, uruchomili�my nowy projekt "ffdshow-tryouts".\r\n\r\n4. Konfiguracja\r\n\r\nInstalator potrafi skonfigurowa� ustawienia g�o�nik�w. Domy�lnie �adowane s� ustawienia systemu operacyjnego (z panelu sterowania).\r\n\r\n5. Odno�niki\r\n\r\nffdshow-tryouts:\r\nhttp://ffdshow-tryout.sourceforge.net/\r\nhttp://sourceforge.net/project/showfiles.php?group_id=173941\r\n\r\nffdshow (stare):\r\nhttp://ffdshow.sourceforge.net/tikiwiki/\r\nhttp://sourceforge.net/projects/ffdshow/\r\n\r\nFFmpeg:\r\nhttp://ffmpeg.mplayerhq.hu/\r\n\r\nMPlayer:\r\nhttp://www.mplayerhq.hu/\r\n\r\nDoom9:\r\nhttp://forum.doom9.org/showthread.php?t=120465\r\n\r\nlub Wikipedia, wolna encyklopedia:\r\nhttp://en.wikipedia.org/wiki/Ffdshow\r\n\r\n5. Kopiowanie\r\n\r\nWszystkie u�yte �r�d�a (z wyj�tkiem planu detekcji wykorzystania mikroprocesora) jak i sam ffdshow s� dystrybuowane na zasadach Powszechnej Licencji Publicznej GPL. Zobacz plik copying.txt.\r\n\r\nLokalizacja:\r\nPiotr Sok�, Radzio, Virtual_ManPL <ffdshow-polish@googlegroups.com>
; Konfiguracja kodera video VFW

[200]
0=Og�lne
1420=Maksymalny odst�p klatek I:
1422=Minimalny odst�p klatki I:
1424=Klatki B
1425=Maks. ilo�� kolejnych klatek B:
1427=Dynamiczna
1431=Udoskonal
1428=Spakowany strumie� bit�w
1429=Zamkni�ty GOP
1572=Ilo�� w�tk�w kodera:
1494=Inne opcje

[230]
0=Mened�er profili kodowania
1467=Profil:
1045=Zmie� &nazw�
1044=&Usu�
1468=Dane:
1=Zamknij

[232]
0=Og�lne
1470=Przestrze� kolor�w:

[269]
0=Og�lne
1472=Profil:
1572=Ilo�� w�tk�w:

[256]
0=Og�lne
1420=Maksymalny odst�p klatek kluczowych IDR:
1422=Minimalny odst�p klatek kluczowych IDR:
1424=Klatki B
1425=Maks. ilo�� kolejnych klatek B:
1427=Dynamiczna
1431=Udoskonal
1572=Ilo�� w�tk�w:
1494=Inne opcje
1885=Stosuj klatki B jako referencyjne
1886=Funkcja por�wnawcza optymalna pod wzgl�dem zniekszta�ce� tempa dla klatek B
1827=Deblock alpha:
1829=Deblock beta:

[228]
0=Og�lne
1866=Zapisz klatki bezpo�rednio do pliku ASF
1420=Odst�p klatek I (sek):
1868=Z�o�ono��:
1870=Chropowato��:
1872=Usu� przeplot

[202]
1446=Koder:
1448=FOURCC:
1450=Tryb:
1453=Ustawienia:
1163=Pomoc
1459=Profile ustawie�
1460=Nie zapisuj ustawie� do rejestru

[203]
0=Napisy
1461=Napisy na pocz�tku filmu
1462=Pierwsza klatka:
1464=Ostatnia klatka:
1466=Napisy na ko�cu filmu
1467=Pierwsza klatka:
1469=Ostatnia klatka:
1471=Tempo redukcji napis�w
1472=
1474=Kwantyzator
1475=Klatki I:
1477=Klatki P:
1479=Wielko�� (kB)
1480=Pocz�tek:
1482=Koniec:
1484=Napisy w odcieniach szaro�ci
1143=Je�li film posiada napisy czo�owe, kt�re wed�ug Ciebie nie potrzebuj� najlepszej jako�ci, wpisz numer pierwszej i ostatni� klatki w pola napis�w czo�owych po zaznaczeniu "Napisy na pocz�tku filmu".\r\nTo samo dotyczy napis�w ko�cowych. Je�li my�lisz, �e napisy ko�cowe potrzebuj� mniej bit�w - kt�re mo�na spo�ytkowa� lepiej w g��wnej cz�ci filmu, tymsamym polepszaj�c jej jako�� - zaznacz "Napisy na ko�cu filmu" oraz wpisz numer pierwszej i ostatniej klatki napis�w ko�cowych.\r\nWarto�� % oznacza procent bitrate'u filmu. Tak wi�c je�li film posiada �rednio 800kb/s a ustawiono 10%, napisy zakodowane zostan� z bitrate'em 80 kb/s.\r\nJe�eli wybra�e� kodowanie napis�w z ustalonym kwantyzatorem, upewnij si� �e zrobi�e� to tak�e dla pierwszego przebiegu! W przeciwnym wypadku porz�dany rozmiar nie zostanie uzyskany!\r\nJe�li chcesz uzyska� okre�lone rozmiary fragment�w filmu z napisami, koder w miar� mo�liwo�ci spr�buje je osi�gn��.

[204]
0=Inna kompresja
1485=U�yj innej kompresji krzywych
1486=Kompresja krzywej:
1488=Wysoki odst�p od �redniej:
1491=Niski odst�p od �redniej:
1494=Automatyczna minimalna wzgl�dna jako��:
1497=R�czna minimalna wzgl�dna jako��:
1500=Premia trybu bias:

[205]
0=Kompresja krzywych
1463=Sceny o wysokiej kompresji:
1420=Sceny o niskiej kompresji:
1422=Op�nienie zwrotu kompresji:
1423=klatek
1505=Zwrot z ukosem
1506=Zwrot proporcjonalny

[206]
0=2 przebiegi - 1-szy przebieg
1424=Plik statystyk:

[207]
0=Og�lne
1425=Przestrze� kolor�w:
1426=Typ kodera:
1427=Model kontekstu:
1420=Odst�p klatek I:
1143=Kodek bezstratny o wysokim wsp�czynniku kompresji, alternatywny do huffyuv, z obs�ug� dodatkowych przestrzeni kolor�w ale du�o wolniejszy.

[209]
0=Og�lne
1529=Przestrze� kolor�w:

[210]
0=Og�lne
1420=Maksymalny odst�p klatek I:
1422=Minimalny odst�p klatek I:
1424=Pr�g r�nicy klatki kluczowej:
1530=Wysoka jako��
1531=Porzucaj klatki
1143=Tego kodeka u�ywaj tylko do cel�w eksperymentalnych! W przysz�o�ci mo�e on zosta� zmodyfikowany w spos�b nie zapewniaj�cy kompatybilno�ci.

[211]
0=Statystyki
1531=Zapisz informacje do debuggera
1533=Zapisz informacje do pliku
1532=Poka� komunikaty b��d�w
1738=Udost�pnij graf DirectShow dla programu GraphEdit
1537=Poka� graf
1538=Oblicz PSNR
1541=Zakodowanych klatek:
1542=kb/s:
1543=Klatek/s:
1544=�redni PSNR:
1545=�redni kwantyzator:

[212]
0=Og�lne
1428=Przestrze� kolor�w:
1429=Spos�b przewidywania:
1314=Skala szaro�ci
1315=U�yj dostosowanych tablic Huffmana

[213]
0=Strumie� wej�cia
1548=Wymu� wej�ciow� palet� kolor�w:
1550=Ustaw przeplot na wej�ciu je�li wysoko�� >
1552=pikseli
1016=Obr�� w pionie
1554=Zezw�l na przetwarzanie obrazu
1555=Ustawienia
1556=Redukcja szumu libavcodec/x264
1460=Si�a redukcji szumu:

[214]
0=Maskowanie
1556=Maskowanie luminancji:
1564=Maskowanie ciemno�ci:
1567=Eliminacja pojedynczych wsp�czynnik�w
1568=Luminancja
1572=Chrominancja
1569=Pr�g:
1573=Pr�g:
1558=Maskowanie z�o�ono�ci czasowej:
1560=Maskowanie z�o�ono�ci przestrzennej:
1576=Maskowanie ramek:
1566=Normalizacja kwantyzacji adaptacyjnej
1571=tak�e DC
1575=tak�e DC
1562=Maskowanie blok�w inter:

[220]
0=Maskowanie
1435=Op�nienie reakcji kodera:
1436=Okres u�redniania:
1437=Wyg�adzenie krzywej bitrate:

[215]
0=Maskowanie
1576=Maskowanie luminancji
1577=Wst�pny filtr optymalizuj�cy chrominancje

[258]
0=Maskowanie
1840=Wyostrzanie:
1842=Czu�o�� szumu:

[219]
0=Kontrola tempa
1635=Tolerancja rozmiaru pliku:
1637=Kompresja kwantyzatora:
1639=Rozmycie kwantyzatora dla 1-szego przebiegu:
1641=Rozmycie kwantyzatora dla 2-go przebiegu:
1643=Maksymalna r�nica kwantyzatora:
1646=Minimalny bitrate:
1435=kb/s
1648=Maksymalny bitrate:
1445=kb/s
1650=Rozmiar bufora strumienia dekodera:
1446=bit�w
1645=U�yj funkcji ci�g�ej by ograniczy� kwantyzator warto�ciami min. i maks.
1143=Kompresja kwantyzatora\r\nJe�li ustawiono warto�� 100%, kwantyzator pozostanie prawie sta�y (sceny dynamiczne b�d� wygl�da�y gorzej). Je�li ustawiono 0%, kwantyzator b�dzie modyfikowany tak by rozmiary wszystkich klatek by�y w przybli�eniu r�wne (sceny statyczne b�d� wygl�da�y gorzej).\r\n\r\nRozmycie kwantyzatora\r\nRozmywa przebieg warto�ci kwantyzatora w czasie: 0% - brak rozmycia, 100% - u�rednia wszystkie przesz�e warto�ci kwantyzatora.\r\n\r\nMaksymalna r�nica kwantyzatora\r\nOgranicza maksymaln� r�nic� kwantyzatora pomi�dzy klatkami.\r\n\r\nMinimalny/Maksymalny bitrate\r\nNieograniczona je�li ustawiono zero.\r\n\r\nRozmiar bufora strumienia dekodera\r\nDla MPEG1/2 ustawia tak�e rozmiar bufora VBV.\r\n\r\nOpis Michael Niedermayer

[222]
0=Strumie� wyj�cia
1438=Strumie� wyj�cia
1654=Przechowuj klatki w pliku AVI
1655=Przechowuj klatki w zewn�trznym pliku
1659=Statystyki libavcodec/x264:
1660=Nie u�ywaj
1661=Zapisz
1662=U�yj
1663=Zapisz i u�yj
1664=Bitrate
1667=Zmie� ilo�� klatek/s
1143=Mo�esz zapisa� ka�d� klatk� do oddzielnego pliku (przydatne z koderem MJPEG): wybierz przechowywanie klatek w pliku nieskompresowanym a w polu nazwy pliku wpisz %i (lub podobn� mask� formatowania).

[223]
0=Kwantyzacja
1441=Typ kwantyzacji:
1699=U�yj kwantyzacji kratowej
1675=Klatki I
1677=Klatki B
1678=Makrobloki
1442=Min. kwantyzator
1443=Maks. kwantyzator
1687=Mno�nik klatek I
1691=Mno�nik klatek B
1689=Offset klatek I
1693=Offset klatek B
1700=Algorytm DCT:
1703=Noise shaping kwantyzatora:
1707=Dok�adno�� MPEG2 DC:
1695=Bias kwantyzatora inter:
1697=Bias kwantyzatora intra:

[226]
0=2 przebiegi - 2-gi przebieg
1847=Symulacja
1424=Plik statystyk dla 1-szego przebiegu:
1842=Nadpisz nowymi statystykami
1844=Plik statystyk dla 2-go przebiegu:
1444=Maksymalny bitrate:
1446=Maks. poprawa kontroli przepe�nienia:
1448=Maks. degradacja kontroli przepe�nienia:
1445=kbit/s
1462=Klatki I
1450=Zwi�ksz o
1452=Je�eli odleg�o�� pomi�dzy klatkami I jest <
1453=klatek...
1454=... redukuj kompresj� klatek I o

[266]
0=Niestandardowe matryce

[216]
0=Szacowanie ruchu
1604=Algorytm decyzyjny makrobloku:
1578=4 wektory ruchu w ka�dym makrobloku
1579=Iteracyjne szacowanie ruchu
1581=Funkcja por�wnania ruchu:
1584=Funkcja por�wnania ruchu subpel:
1587=Funkcja por�wnania makroblok�w:
1602=Jako�� udoskonalenia:
1590=Typ i rozmiar diamentu:
1594=Ocena ruchu wst�pnego przebiegu:
1592=Przewidywanych ruch�w z poprzedniej klatki:
1596=Funkcja por�wnania ruchu:
1599=Typ i rozmiar diamentu:
1607=Optymalizacja zniekszta�cenia tempa dla CBP
1606=Pr�buj zawsze bez ruchu

[238]
0=Szacowanie ruchu
1779=Udoskonalenie subpel:
1780=Przewidywanie ruchu klatek B:
1782=Metoda szacowania ruchu:
1528=Zakres szacowania ruchu:
1519=Maksymalna ilo�� klatek referencyjnych:
1525=Maksymalna d�ugo�� wektora ruchu (w pikselach):
1527=U�yj informacji o chrominancji dla subpel i trybu decyzyjnego w klatkach P
1506=Flagi analizatora intra:
1508=Flagi analizatora inter:

[218]
0=Szacowanie ruchu
1614=U�yj informacji o chrominancji
1615=Profil precyzji detekcji ruchu:
1626=Profil trybu VHQ:

[227]
0=Symulacja 2-go przebiegu
1854=Analizuj
1855=Symuluj
1861=Bajt�w:
1862=Liczba klatek:
1864=�redni rozmiar klatki:
1865=�redni kwantyzator:
1439=Udzia� procentowy kwantyzatora
1440=Udzia� liczbowy kwantyzatora

[268]
1844=Si�a kwantyzacji adaptacyjnej:

[290]
0=1. O koderze video ffdshow\r\n\r\nKodek Video for Windows (VFW) i DirectShow. Do kompresji u�ywa bibliotek� libavcodec z projektu FFmpeg. Kilka innych bibliotek kompresji takich jak xvidcore i libtheora jest tak�e obs�ugiwanych.\r\n\r\n2. Cechy\r\n\r\n- r�ne metody kompresji:\r\n  H.264,\r\n  kompatybilne MPEG-4 (Xvid, DivX) z u�yciem libavcodec lub Xvid,\r\n  kompatybilne Divx 3, MSMPEG4v2, MSMPEG4v1,\r\n  WMV1/7, WMV2/8,\r\n  H263, H263+,\r\n  HuffYUV w przestrzeni kolor�w YV12,\r\n  MJPEG,\r\n  MPEG 1/2,\r\n  Theora (nie nadaje si� do regularnego u�ytku, specyfikacja formatu nie jest jeszcze stabilna),\r\n\r\n- wszystkie typowe tryby kodowania: sta�y bitrate, ustalony kwantyzator, ustalona jako��, dwu przebiegowe kodowanie (zale�nie od w�a�ciwo�ci kompresora),\r\n- dla libavcodec i Xvid szczeg�owy wyb�r metody estymacji ruchu,\r\n- minimalna i maksymalna odleg�o�� pomi�dzy klatkami I,\r\n- wyb�r minimalnego i maksymalnego kwantyzatora, typu kwantyzatora oraz kwantyzacji kratowej dla libavcodec,\r\n- kwantyzacja adaptacyjna (inaczej maskowanie) dla libavcodes i Xvid, eliminacja pojedynczych wsp�czynnik�w,\r\n- wyb�r jako�ci kompresji dla czo�owych i ko�cowych napis�w,\r\n- dwa algorytmy kompresji krzywych dla 2-go stopnia kodowania dwu stopniowego dzi�ki tw�rcom Xvid'a,\r\n- symulacja drugiego przebiegu kodowania: pomimo �e ma�o precyzyjna, to nadal pomocna w doborze zaawansowanych parametr�w kompresji krzywych,\r\n- mo�liwo�� u�ycia natywnego kodowania libavcodec dla drugiego stopnia,\r\n- przetwarzanie obrazu z u�yciem filtr�w ffdshow,\r\n- graf podczas kodowania je�li program koduj�cy nie oferuje w�asnego,\r\n- obs�uga klatek typu B: od jednej do o�miu nast�puj�cych po sobie klatek B,\r\n- obs�uga quarterpixel i GMC (Global Motion Compensation) dla MPEG4,\r\n- mo�liwo�� kodowania z przeplotem,\r\n- kodery libavcodec MPEG4/MPEG2/MPEG1, xvidcore 1.2 i x264 s� wielow�tkowe,\r\n- kodery libavcodec posiadaj� mo�liwo�� wy�wietlania komunikat�w o b��dach,\r\n- dekompresja.\r\n\r\n3. ffdshow-tryouts\r\n\r\nffdshow pierwotnie zosta� opracowany przez Milan'a Cutka. Od czasu gdy Milan Cutka zaprzesta� aktualizowania w 2006 roku, uruchomili�my nowy projekt "ffdshow-tryouts".\r\n\r\n4. Odno�niki\r\n\r\nffdshow-tryouts:\r\nhttp://ffdshow-tryout.sourceforge.net/\r\nhttp://sourceforge.net/project/showfiles.php?group_id=173941\r\n\r\nffdshow (stare):\r\nhttp://ffdshow.sourceforge.net/tikiwiki/\r\nhttp://sourceforge.net/projects/ffdshow/\r\n\r\nFFmpeg:\r\nhttp://ffmpeg.mplayerhq.hu/\r\n\r\nXvid:\r\nhttp://www.xvid.org/\r\n\r\nMPlayer:\r\nhttp://www.mplayerhq.hu/\r\n\r\nMJPEGtools:\r\nhttp://mjpeg.sourceforge.net/\r\n\r\nDoom9:\r\nhttp://forum.doom9.org/showthread.php?t=120465\r\n\r\nlub Wikipedia, wolna encyklopedia:\r\nhttp://en.wikipedia.org/wiki/Ffdshow\r\n\r\n5. Kopiowanie\r\n\r\nffdshow jest dystrybuowany na zasadach Powszechnej Licencji Publicznej GPL. Zobacz plik copying.txt.\r\n\r\nLokalizacja:\r\nPiotr Sok�, Radzio, Virtual_ManPL <ffdshow-polish@googlegroups.com>

[2244]
0=Opcje dekodera
2245=Zastosuj dynamiczne pasmo kompresji, je�li dost�pne (dekodery AC3 oraz E-AC3)

[296]
2222=Zacznij od:
2224=Podwojenie liczby klatek
2223=Pomi� sprawdzanie przestrzennego przeplotu

[241]
1528=Wyostrz
1529=Dwustronnie
1531=Po��cz luminancyjn� i chrominancyjn� matryc� ruchu
1530=Zmapuj
1526=Pr�g:

[251]
1730=Pr�g:
1728=Tryb:
1727=Ochrona przed artefaktami

[239]
1210=Pionowy filtr
1207=Si�a szukania:

[240]
1367=Pr�g:
1212=Si�a szukania:
